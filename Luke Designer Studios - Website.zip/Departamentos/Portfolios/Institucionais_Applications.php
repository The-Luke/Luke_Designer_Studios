<!doctype html>
<html class="no-js" lang="pt-br">
     <head>
         
        <meta charset="utf-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="descripton" content="Desde a primeira até a última todas estão aqui, categoriazadas nossas criações e projetos em andamento, e com importantes dados a respeito do desenvolvimento da aplicação web..">

        <title>E-Commerce - Luke Designer Studios</title>

        <!-- Todos os Estilos -->


        <!-- Estilos do Foundation -->
        <link rel="stylesheet" href="../../css/Foundation/foundation.css">
        <link rel="stylesheet" href="../../css/Foundation/app.css">
        <!-- /Estilos do Foundation -->


        <!-- Estilos Gerais -->
        <link rel="stylesheet" href="../../css/Estilos_Gerais/font_face.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Estilo_Geral.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Menu_Principal.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Off_Canvas.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Header.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Footer.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Barra_Carregamento.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Sub_Menu.css">
        <link rel="icon" href="../../imagens/Imagens_PNG/Icon_logo.png">
        <!-- /Estilos Gerais -->


        <!-- Estilos da Página -->
        <link rel="stylesheet" href="../../css/Portfolios/Portfolios.css">
        <!-- /Estilos da Página -->


        <!-- /Todos os Estilos -->
        
        <?php include('../../PHP/conecta.php"'); ?>

    </head>
    <body>    
      
    <!-- Menu Off Canvas -->	

    <div class="off-canvas-wrapper">
        <div class="off-canvas position-left" data-transition="overlap" id="Open_Canvas" data-off-canvas> 
            
            <div class="Menu_Vertical">
                <ul class="Menu_Vertical_Links">
                    <label>Aplicações Web</label>

                    <li class="item">
                        <a href="../Web_Applications/WebSites.php">WebSites</a>
                    </li>

                    <li class="item">
                        <a href="../Web_Applications/Aplicativos.php">Aplicativos</a>
                    </li>

                    <li class="item">
                        <a href="../Web_Applications/Suporte.php">Suporte</a>
                    </li>

                    <li class="item">
                        <a href="../Web_Applications/Wireframes.php">Wireframes</a>
                    </li>
                    
                    <label>Portfólios</label>

                    <li class="item">
                        <a href="../Portfolios/All_Applications.php">Todas Aplicações</a>
                    </li>

                    <li class="item">
                        <a href="../Portfolios/Institucionais_Applications.php">Aplicações Institucionais</a>
                    </li>

                    <li class="item">
                        <a href="../Portfolios/E-Commerce_Applications.php">Aplicações E-Commerce</a>
                    </li>
                    
                    <label>Suporte</label>

                    <li class="item">
                        <a href="../Suporte/Duvidas.php">Dúvidas</a>
                    </li>

                    <li class="item">
                        <a href="../Suporte/Termos_e_Politica.php">Termos e Política</a>
                    </li>

                    <li class="item">
                        <a href="../Suporte/Fale_Conosco.php">Fale Conosco</a>
                    </li>
                    
                    <label>Sobre nós</label>

                    <li class="item">
                        <a href="../Institucional/Quem_Somos.php">Quem Somos</a>
                    </li>

                    <li class="item">
                        <a href="../Institucional/Linha_do_Tempo.php">Linha do Tempo</a>
                    </li>

                    <li class="item">
                        <a href="../Institucional/Nossos_Servicos.php">Nossos Serviços</a>
                    </li>
                </ul>
                
                <a href="../../index.php" class="Menu_Vertical_Button">Página Inicial</a>
            </div>
        </div>

        <!-- /Menu Off-canvas -->	


		<!-- Conteúdo da Página -->

        <div class="off-canvas-content" data-off-canvas-content>

            <!-- Menu Principal	-->

            <div class="Menu_Principal">   
                <div class="Menu_Principal_Ajuste">

                    <div class="logo_menu"> 
                        <a href="../../index.php">L . D . S</a>
                    </div>

                    <div class="base_options_menu">
                        <ul class="options_menu">
                            <li><a href="../Web_Applications/WebSites.php">Aplicações Web</a></li>
                            <li><a href="../Portfolios/All_Applications.php">Portfólios</a></li>
                            <li><a href="../Suporte/Duvidas.php">Suporte</a></li>
                            <li><a href="../Institucional/Quem_Somos.php">Institucional</a></li>
                            <li><a href="../Design/Logotipos.php">Serviços de Designer</a></li>
                        </ul>				
                    </div>

                    <div class="button_base">
                        <a href="../Suporte/Fale_Conosco.php" class="button_menu">Entre em Contato</a>
                    </div>

                </div>
            </div>    

            <!-- /Menu Principal -->


            <!-- Header	-->

            <div class="base_1024px">
                <div class="header_inf">			
                    <h1>Po<span style="letter-spacing: 4px;">r</span><span style="letter-spacing: 4px;">t</span>fólios</h1>
                    <p>Desde a primeira até a última todas estão aqui, categoriazadas nossas criações e projetos em andamento, e com importantes dados a respeito do desenvolvimento da aplicação web.</p>
                </div>    
            </div>

            <div id="particles-js"></div>

            <div class="header_curva"></div>

            <!-- /Header -->


            <!-- Sub Menu -->	

            <div class="base_1024px">
                <ul class="Sub_Menu">
                    <li><a class="neutro" href="All_Applications.php">Todas Aplicações</a></li>
                    <li><a class="ativo" href="Institucionais_Applications.php">Aplicações Institucionais</a></li>
                    <li><a class="neutro" href="E-Commerce_Applications.php">Aplicações E-Commerce</a></li>
                </ul>					
            </div>

            <!-- /Sub Menu -->	    



            <!-- Descrição Inicial -->

            <div class="base_1024px">
                <div class="first-description">
                    <h1>Aplicações Institucionais</h1> 
                    <p>Desde as nossas primeiras criações até as últimas, todos os nossos trabalhos sejam aplicativos ou websites estam guardados aqui e claro eternizados em nossa história, confira os nossos trabalhos para ver sua qualidade e ter segurança, somos muito perfeccionistas com nossas criações.</p>
                </div> 
                <hr class="dashed">
            </div>

            <!-- Descrição Inicial -->  

            
            
            <!-- Portfólio -->		
    
            <div class="base_1024px ajustar_float">
                <div class="Portfolio">

                    <div class="Portfolio_IMG">
                        <img src="https://lukedesigner.com/imagens/Imagens_PNG/Exemplo_IMG2_imac2015retina_front.png">
                    </div>

                    <div class="Portfolio_INF">
                        <p>Aplicação Web - WebSite</p>
                        <h3>The Luke's Store</h3>

                        <ul>
                            <li>E-Commerce</li>
                            <li>Mascote Incluso</li>
                            <li>Logotipo Incluso</li>
                            <li>Resposividade Alta</li>
                            <li>Indexado Pelo Google</li>
                            <li>Desenvolvido em 180 Dias</li>
                            <li>Data de Hospedagem 03/05/2018</li>
                        </ul>
                        <br>
                        <a class="Portfolio_Button" href="#">Conferir WebSite</a>
                    </div>

                </div>
            </div>
            
            <!-- /Portfólio -->		

           
            <!-- Footer -->		

            <div class="footer">
                <div class="footer_section_1">
                    <div class="base_1200px ajustar_float">
                        <div class="footer_chamada_base">
                            <h5>Peça sua aplicação web hoje mesmo!</h5>
                            <p>Venha já conferir as aplicações web que temos a oferecer.</p>
                        </div>

                        <div class="footer_button_base">
                            <a class="footer_button" href="../Web_Applications/WebSites.php">Conferir Aplicações</a>
                        </div>
                    </div>
                </div>

                <div class="footer_section_2">
                    <div class="base_1200px_footer ajustar_float">
                        <div class="footer_inf_base">
                            <div class="footer_lista_ajuste">
                                <div class="inf_item">
                                    <div class="Departamentos">
                                        <h4>Departamentos</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Web_Applications/WebSites.php">Aplicações Web</a></li>
                                            <li><a href="../Design/Logotipos.php">Serviços de Designer</a></li>
                                            <li><a href="../Suporte/Duvidas.php">Nosso Suporte</a></li>
                                            <li><a href="../Institucional/Quem_Somos.php">Institucional</a></li>
                                            <li><a href="../Portfolios/E-Commerce_Applications.php">Portfólios</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="inf_item">
                                    <div class="Institucional">
                                        <h4>Institucional</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Institucional/Quem_Somos.php">Quem Somos</a></li>
                                            <li><a href="../Institucional/Linha_do_Tempo.php">Linha do Tempo</a></li>
                                            <li><a href="../Institucional/Trabalhe_Conosco.php">Trabalhe Conosco</a></li>
                                            <li><a href="../Institucional/Nossos_Servicos.php">Nossos Serviços</a></li>
                                            <li><a href="../Institucional/Membros/Luke.php">Nosso Lider</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="inf_item">
                                    <div class="Suporte">
                                        <h4>Ajuda e Suporte</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Suporte/Duvidas.php">Dúvidas</a></li>
                                            <li><a href="../../index.php">Página Inicial</a></li>
                                            <li><a href="../Suporte/Fale_Conosco.php#RedesSociais">Redes Sociais</a></li>
                                            <li><a href="../Suporte/Termos_e_Politica.php">Termos e Política</a></li>
                                            <li><a href="../Suporte/Fale_Conosco.php">Fale Conosco</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="inf_item_contato">
                                <div class="Contato">
                                    <h4>Fale Conosco</h4>

                                    <p>Facebook: <a href="https://www.facebook.com/LukeDesignerStudios/">@LukeDesignerStudios</a></p>
                                    <p class="Twitter_P">Twitter: <a href="https://twitter.com/studios_luke">TheLukeDesigner</a></p>

                                    <?php 
                                    $consulta = mysql_query("SELECT * FROM tb_contato");
                                    while ($dados = mysql_fetch_array($consulta)){ ?>

                                    <p>Email:
                                        <?php echo $dados['email']; ?> </p>
                                    <p>Telefone:
                                        <?php echo $dados['telefone']; ?>
                                    </p>

                                    <?php }?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="footer_nav">
                    <div class="base_1200px ajustar_float">
                        <div class="footer_nav_ajuste">
                            <div class="ajustar_float">
                                <div class="footer_logo">
                                    <a href="index.php" class="LDS_LOGO">L . D . S</a>
                                </div>

                                <div class="links_footer_base">
                                    <ul class="links_footer">
                                        <li><a href="index.php">Página Inicial</a></li>
                                        <li><a href="../Suporte/Termos_e_Politica.php">Termos e Política</a></li>
                                        <li><a data-open="Open_Canvas" aria-expanded="false" aria-controls="Open_Canvas">Mapa do site</a></li>
                                    </ul>     
                                </div>
                            </div>

                            <p class="copyright">© 2018 ‐ Luke Designer Studios.</p>
                        </div>

                        <div class="home_social_base">
                            <ul class="home-social">
                                <li><a href="https://www.facebook.com/LukeDesignerStudios/" class="facebook"></a></li>
                                <li><a href="https://twitter.com/studios_luke" class="twitter"></a></li>
                                <li><a href="Suporte/Fale_Conosco.php" class="contato"></a></li>
                                <li><a href="https://www.linkedin.com/company/luke-designer-studios/" class="linkedin"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- /Footer -->

            
        </div> <!-- *off-canvas-content -->   
     </div> <!-- /off-canvas-wrapper -->	 	  

        
    <!-- /Conteúdo da Página -->


    <!-- Scripts -->  
      
    <!-- Base do Foundation -->
    <script src="../../js/Foundation/vendor/jquery.js"></script>
    <script src="../../js/Foundation/vendor/what-input.js"></script>
    <script src="../../js/Foundation/vendor/foundation.js"></script>
    <script src="../../js/Foundation/app.js"></script>
  
	<script>
      $(document).foundation();
    </script>  
    <!-- /Base do Foundation -->  
	
         
    <!-- Barra de Carregamento -->  
    <script src="../../js/Barra_de_Carregamento/pace.min.js"></script>
    <!-- /Barra de Carregamento -->    

      
    <!-- Efeito de Particulas -->    
	<script src="../../js/Particles/particles.js"></script>			
	<script src="../../js/Particles/app.js"></script>
    <!-- /Efeito de Particulas -->      
      
    <!-- /Scripts --> 
      
  </body>
</html>