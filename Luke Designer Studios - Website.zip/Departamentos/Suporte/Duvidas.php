<!doctype html>
<html class="no-js" lang="pt-br">
  <head>
        
        <meta charset="utf-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="descripton" content="Você ainda tem alguma dúvida em relação a algum de nossos serviços? Não se preocupe você está na página certa.">

        <title>Dúvidas - Luke Designer Studios</title>

        <!-- Todos os Estilos -->


        <!-- Estilos do Foundation -->
        <link rel="stylesheet" href="../../css/Foundation/foundation.css">
        <link rel="stylesheet" href="../../css/Foundation/app.css">
        <!-- /Estilos do Foundation -->


        <!-- Estilos Gerais -->
        <link rel="stylesheet" href="../../css/Estilos_Gerais/font_face.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Estilo_Geral.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Menu_Principal.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Off_Canvas.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Header.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Footer.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Barra_Carregamento.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Sub_Menu.css">
        <link rel="icon" href="../../imagens/Imagens_PNG/Icon_logo.png">
        <!-- /Estilos Gerais -->


        <!-- Estilos da Página -->
        <link rel="stylesheet" href="../../css/Suporte/Duvidas.css">
        <!-- /Estilos da Página -->


        <!-- /Todos os Estilos -->
        
        
        <?php

            // Conectar ao Banco de Dados 
            $conecta = mysql_connect("mysql.hostinger.com","u447384975_luke","Dragonborne#78") or die ("Não foi possível conectar com o banco de dados");
            mysql_select_db("u447384975_lds",$conecta)or die ("Não foi possível selecionar o banco de dados");

            // Resolver problemas com acentuação 
            mysql_query("SET NAMES 'utf8'");
            mysql_query('SET character_set_connection=utf8');
            mysql_query('SET character_set_client=utf8');
            mysql_query('SET character_set_results=utf8');
        ?>

    </head>
    <body>    
       
    <!-- Menu Off Canvas -->	

    <div class="off-canvas-wrapper">
        <div class="off-canvas position-left" data-transition="overlap" id="Open_Canvas" data-off-canvas> 
            
            <div class="Menu_Vertical">
                <ul class="Menu_Vertical_Links">
                    <label>Aplicações Web</label>

                    <li class="item">
                        <a href="../Web_Applications/WebSites.php">WebSites</a>
                    </li>

                    <li class="item">
                        <a>Aplicativos</a>
                    </li>

                    <li class="item">
                        <a href="../Web_Applications/Suporte.php">Suporte</a>
                    </li>

                    <li class="item">
                        <a href="../Web_Applications/Wireframes.php">Wireframes</a>
                    </li>
                    
                    <label>Portfólios</label>

                    <li class="item">
                        <a href="../Portfolios/All_Applications.php">Todas Aplicações</a>
                    </li>

                    <li class="item">
                        <a>Aplicações Institucionais</a>
                    </li>

                    <li class="item">
                        <a href="../Portfolios/E-Commerce_Applications.php">Aplicações E-Commerce</a>
                    </li>
                    
                    <label>Suporte</label>

                    <li class="item">
                        <a href="../Suporte/Duvidas.php">Dúvidas</a>
                    </li>

                    <li class="item">
                        <a href="../Suporte/Termos_e_Politica.php">Termos e Política</a>
                    </li>

                    <li class="item">
                        <a href="../Suporte/Fale_Conosco.php">Fale Conosco</a>
                    </li>
                    
                    <label>Institucional</label>

                    <li class="item">
                        <a href="../Institucional/Quem_Somos.php">Quem Somos</a>
                    </li>

                    <li class="item">
                        <a href="../Institucional/Linha_do_Tempo.php">Linha do Tempo</a>
                    </li>

                    <li class="item">
                        <a href="../Institucional/Nossos_Servicos.php">Nossos Serviços</a>
                    </li> 
                    
                    <label>Serviços de Designer</label>

                    <li class="item">
                        <a href="../Design/Logotipos.php">Mascotes e Logotipos</a>
                    </li>

                </ul>
                
                <a href="../../index.php" class="Menu_Vertical_Button">Página Inicial</a>
            </div>
        </div>

        <!-- /Menu Off-canvas -->	



		<!-- Conteúdo da Página -->

        <div class="off-canvas-content" data-off-canvas-content>

            <!-- Menu Principal	-->

            <div class="Menu_Principal">   
                <div class="Menu_Principal_Ajuste">

                    <div class="logo_menu"> 
                        <a href="../../index.php">L . D . S</a>
                    </div>

                    <div class="base_options_menu">
                        <ul class="options_menu">
                            <li><a href="../Web_Applications/WebSites.php">Aplicações Web</a></li>
                            <li><a href="../Portfolios/All_Applications.php">Portfólios</a></li>
                            <li><a href="../Suporte/Duvidas.php">Suporte</a></li>
                            <li><a href="../Institucional/Quem_Somos.php">Institucional</a></li>
                            <li><a href="../Design/Logotipos.php">Serviços de Designer</a></li>
                        </ul>				
                    </div>

                    <div class="button_base">
                        <a href="../Suporte/Fale_Conosco.php" class="button_menu">Entre em Contato</a>
                    </div>

                </div>
            </div>    

            <!-- /Menu Principal -->

		
		    <!-- Header -->

            <div class="base_1024px">
                <div class="header_inf">			
                    <h1>Supo<span style="letter-spacing: 3px;">r</span>te</h1>
                    <p>Para que não exista nenhuma dúvida sobre nós ou nossos serviços, desenvolvemos na guia suporte três importantes páginas: dúvidas, termos e política e claro fale conosco.</p>
                </div>    
            </div>

            <div id="particles-js"></div>

            <div class="header_curva"></div>

            <!-- /Header -->


            <!-- Sub Menu -->	

            <div class="base_1024px">
                <ul class="Sub_Menu">
                    <li><a class="ativo" href="Duvidas.php">Dúvidas</a></li>
                    <li><a class="neutro" href="Termos_e_Politica.php">Termos e Política</a></li>
                    <li><a class="neutro" href="Fale_Conosco.php">Fale Conosco</a></li>
                </ul>					
            </div>

            <!-- /Sub Menu -->	    


            <!-- Descrição Inicial -->

            <div class="base_1024px">
                <div class="first-description">
                    <h1>Pergutas Frequentes</h1> 
                    <p>Você ainda tem alguma dúvida em relação a algum de nossos serviços? Não se preocupe você está na página certa, todas as suas dúvidas podem ser tiradas logo a baixo independente de qual seja, caso ela não esteja listada em nossos tópicos, por favor mande a sua pergunta para nós.</p>
                </div> 
                <hr class="dashed">
            </div>

            <!-- Descrição Inicial -->  


            <!-- Perguntas -->

            <div class="Base_850px">
                <div class="Duvidas">
                    <img src="../../imagens/Imagens_SVG/Suporte/WebSite_Responsivo.svg">
                    <h2>Aplicação Web</h2>

                    <hr>
                    <h4>1. Como adquirir um aplicação web?</h4>
                    <p>Você precisa apenas acessar a página <span class="under_text"><a href="../Web_Applications/WebSites.php">aplicações web</a></span> e fazer seu pedido.</p>
                    <hr>

                    <h4>2. Qual o tempo de produção de um aplicação web?</h4>
                    <p>O tempo de produção irá depender de acordo com a categoria escolhida.</p>
                    <hr>

                    <h4>3. O que é a manutenção única?</h4>
                    <p>Um serviço em que nós realizamos mudanças no layout de uma aplicação web.</p>
                    <hr>

                    <h4>4. O que é a administração mensal?</h4>
                    <p>Um serviço em que durante 30 dias realizamos mudanças no layout de uma aplicação web.</p>
                    <hr>

                    <h4>5. O que acontece após o pedido de uma aplicação web?</h4>
                    <p>Dentro de 24h nossa equipe entrará em contato com você para agendar uma entrevista.</p>
                    <hr>

                    <h4>6. O que é wireframe?</h4>
                    <p>Wireframe é um desenho básico, que demonstra de forma direta a arquitetura de como o objeto (interface, página da internet, modelo, produto, etc.) final será.</p>
                    <hr>

                    <h4>7. Quanto custa uma aplicação web?</h4>
                    <p>O valor dependerá da aplicação web escolhida, e será negóciado em entrevista com o cliente.</p>
                    <hr>

                    <br>
                </div>
            </div>
                     
            <div class="Base_850px">
                <div class="Duvidas">
                    <img src="../../imagens/Imagens_SVG/Suporte/The_Engrenagem.svg">
                    <h2>Suporte</h2>

                    <hr>
                    <h4>1. Quando os termos e política são atualizados?</h4>
                    <p>Eles podem ser atualizados mensalmente, a cada mudança os clientes serão notificados.</p>
                    <hr>

                    <h4>2. Qual a importancia de ler os termos e política?</h4>
                    <p>Para saber todas as nossas condições e regras, sobre os nossos serviços oferecidos.</p>
                    <hr>

                    <h4>3. Quais são os horários de atentedimento?</h4>
                    <p>Horários de atentedimento são das 13:00 da manhã ás 18:00 da noite, de segunda a sábado.</p>
                    <hr>

                    <h4>4. Como entrar em contato com vocês?</h4>
                    <p>Acessando a nossa página <span class="under_text"><a href="Fale_Conosco.php">fale conosco</a></span> você terá todas as opções para entrar contato.</p>
                    <hr>

                    <h4>5. Quais as redes sociais Luke Designer Studios? </h4>
                    <p>Nós estamos presentes nas seguintes redes sociais: <a href="https://www.facebook.com/LukeDesignerStudios">Facebook</a>, <a href="https://twitter.com/studios_luke">Twitter</a> e <a href="https://www.linkedin.com/company/luke-designer-studios/">Linkedin</a>.</p>
                    <hr>

                    <br>
                </div>
            </div>
            
            <div class="Base_850px">
                <div class="Duvidas">
                    <img src="../../imagens/Imagens_SVG/Suporte/Nuvem_Hospedagem.svg">
                    <h2>Hospedagem</h2>

                    <hr>
                    <h4>1. O que é uma hospedagem?</h4>
                    <p>É o serviço de armazenamento e disponibilização de uma aplicação web na internet.</p>
                    <hr>

                    <h4>2. O que é um domínio?</h4>
                    <p>É o um nome que serve para localizar e identificar outras aplicações web na internet.</p>
                    <hr>

                    <h4>3. Posso trocar meu domíno?</h4>
                    <p>Pode, porém não é muito recomendável estar trocando, o ideal é escolher um definitivo.</p>
                    <hr>

                    <h4>4.Como faço a renovação da minha hospedagem?</h4>
                    <p>Entre em contato com nossa equipe, e nós faremos a hospedagem.</p>
                    <hr>

                    <h4>5. Posso escolher qualquer nome no meu domínio?</h4>
                    <p>Nem todos os nomes estão disponíveis, deve ser um nome que ninguém tenha escolhido.</p>
                    <hr>

                    <br>
                </div>
            </div>
            
            <!-- /Perguntas -->

            
            <!-- Enviar Pergunta -->	

            <div class="Question_Box">
                <div class="base_1024px ajustar_float">

                    <div class="Question_Box_Icone"></div>
                    <h2>Mande sua Pergunta</h2>

                    <form class="form_padrao" action="Code_Form_Pergunta.php" method="post">
                        <div class="Base_700px ajustar_float">
                            <div class="Question_Input_Base_1 Question_Input">
                                <input type="text" placeholder="Sua Pergunta" name="pergunta" style="border-radius: 5px 0px 0px 5px;">
                            </div>

                            <div class="Question_Input_Base_2 Question_Input">
                                <input type="email" placeholder="Seu Email" name="email">
                            </div>

                            <div class="Question_Input_Base_3">
                                <button type="submit" class="Question_Input_Button">Enviar Pergunta</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- /Enviar Pergunta -->	
            
        
            <!-- Footer -->		

            <div class="footer" style="margin-top: 0px;">
                <div class="footer_section_1">
                    <div class="base_1200px ajustar_float">
                        <div class="footer_chamada_base">
                            <h5>Peça sua aplicação web hoje mesmo!</h5>
                            <p>Venha já conferir as aplicações web que temos a oferecer.</p>
                        </div>

                        <div class="footer_button_base">
                            <a class="footer_button" href="../Web_Applications/WebSites.php">Conferir Aplicações</a>
                        </div>
                    </div>
                </div>

                <div class="footer_section_2">
                    <div class="base_1200px_footer ajustar_float">
                        <div class="footer_inf_base">
                            <div class="footer_lista_ajuste">
                                <div class="inf_item">
                                    <div class="Departamentos">
                                        <h4>Departamentos</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Web_Applications/WebSites.php">Aplicações Web</a></li>
                                            <li><a href="../Design/Logotipos.php">Serviços de Designer</a></li>
                                            <li><a href="../Suporte/Duvidas.php">Nosso Suporte</a></li>
                                            <li><a href="../Institucional/Quem_Somos.php">Institucional</a></li>
                                            <li><a href="../Portfolios/E-Commerce_Applications.php">Portfólios</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="inf_item">
                                    <div class="Institucional">
                                        <h4>Institucional</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Institucional/Quem_Somos.php">Quem Somos</a></li>
                                            <li><a href="../Institucional/Linha_do_Tempo.php">Linha do Tempo</a></li>
                                            <li><a href="../Institucional/Trabalhe_Conosco.php">Trabalhe Conosco</a></li>
                                            <li><a href="../Institucional/Nossos_Servicos.php">Nossos Serviços</a></li>
                                            <li><a href="../Institucional/Membros/Luke.php">Nosso Lider</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="inf_item">
                                    <div class="Suporte">
                                        <h4>Ajuda e Suporte</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Suporte/Duvidas.php">Dúvidas</a></li>
                                            <li><a href="../Suporte/Termos_e_Politica.php#Pagamento">Pagamento</a></li>
                                            <li><a href="../../index.php">Página Inicial</a></li>
                                            <li><a href="../Suporte/Termos_e_Politica.php">Termos e Política</a></li>
                                            <li><a href="../Suporte/Fale_Conosco.php">Fale Conosco</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="inf_item_contato">
                                <div class="Contato">
                                    <h4>Fale Conosco</h4>

                                    <p>Facebook: <a href="https://www.facebook.com/LukeDesignerStudios/">@LukeDesignerStudios</a></p>
                                    <p class="Twitter_P">Twitter: <a href="https://twitter.com/studios_luke">TheLukeDesigner</a></p>

                                    <?php 
                                    $consulta = mysql_query("SELECT * FROM tb_contato");
                                    while ($dados = mysql_fetch_array($consulta)){ ?>

                                    <p>Email:
                                        <?php echo $dados['email']; ?> </p>
                                    <p>Telefone:
                                        <?php echo $dados['telefone']; ?>
                                    </p>

                                    <?php }?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="footer_nav">
                    <div class="base_1200px ajustar_float">
                        <div class="footer_nav_ajuste">
                            <div class="ajustar_float">
                                <div class="footer_logo">
                                    <a href="../../index.php" class="LDS_LOGO">L . D . S</a>
                                </div>

                                <div class="links_footer_base">
                                    <ul class="links_footer">
                                        <li><a href="../../index.php">Página Inicial</a></li>
                                        <li><a href="../Suporte/Termos_e_Politica.php">Termos e Política</a></li>
                                        <li><a data-open="Open_Canvas" aria-expanded="false" aria-controls="Open_Canvas">Mapa do site</a></li>
                                    </ul>     
                                </div>
                            </div>

                            <p class="copyright">© 2018 ‐ Luke Designer Studios.</p>
                        </div>

                        <div class="home_social_base">
                            <ul class="home-social">
                                <li><a href="https://www.facebook.com/LukeDesignerStudios/" class="facebook"></a></li>
                                <li><a href="https://twitter.com/studios_luke" class="twitter"></a></li>
                                <li><a href="../Suporte/Fale_Conosco.php" class="contato"></a></li>
                                <li><a href="https://www.linkedin.com/company/luke-designer-studios/" class="linkedin"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- /Footer -->

            
            
        </div> <!-- *off-canvas-content -->   
     </div> <!-- /off-canvas-wrapper -->	 	  

        
    <!-- /Conteúdo da Página -->


    <!-- Scripts -->  
      
    <!-- Base do Foundation -->
    <script src="../../js/Foundation/vendor/jquery.js"></script>
    <script src="../../js/Foundation/vendor/what-input.js"></script>
    <script src="../../js/Foundation/vendor/foundation.js"></script>
    <script src="../../js/Foundation/app.js"></script>
  
	<script>
      $(document).foundation();
    </script>  
    <!-- /Base do Foundation -->  
	
         
    <!-- Barra de Carregamento -->  
    <script src="../../js/Barra_de_Carregamento/pace.min.js"></script>
    <!-- /Barra de Carregamento -->    

      
    <!-- Efeito de Particulas -->    
	<script src="../../js/Particles/particles.js"></script>			
	<script src="../../js/Particles/app.js"></script>
    <!-- /Efeito de Particulas -->      
      
    <!-- /Scripts -->  
	  
  </body>
</html>