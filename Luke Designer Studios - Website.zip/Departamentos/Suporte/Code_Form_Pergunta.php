<?php
header('Content-Type: text/html; charset=UTF-8');

$para = "lukedesigner@hotmail.com";
$assunto = "WebSite - Pergunta";
$assunto = '=?UTF-8?B?'.base64_encode($assunto).'?=';

$email = $_POST['email'];
$pergunta = $_POST['pergunta'];

$corpo = "<fieldset>
            <legend>
                <h3 style='font-family:Arial,Helvetica,sans-serif;font-size: 24px;color:#2A2E31;margin: 0;'>Informações do Cliente</h3>
            </legend>

            <strong> Email:</strong> $email <br>
            <strong> Pergunta:</strong> $pergunta<br>
            
        </fieldset>";

$header = "MIME-Version: 1.1\n";
$header .= 'Content-type: text/html;' . "\n";
$header .= "From: $email Reply-to: $email\n";

mail($para,$assunto,$corpo,$header);

?>

