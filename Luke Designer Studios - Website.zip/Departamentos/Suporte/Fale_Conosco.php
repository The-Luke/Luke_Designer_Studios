<!doctype html>
<html class="no-js" lang="pt-br">
 <head>
        
        <meta charset="utf-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="descripton" content="Entre em contato conosco pelo nosso formulário.">

        <title>Fale Conosco - Luke Designer Studios</title>

        <!-- Todos os Estilos -->


        <!-- Estilos do Foundation -->
        <link rel="stylesheet" href="../../css/Foundation/foundation.css">
        <link rel="stylesheet" href="../../css/Foundation/app.css">
        <!-- /Estilos do Foundation -->


        <!-- Estilos Gerais -->
        <link rel="stylesheet" href="../../css/Estilos_Gerais/font_face.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Estilo_Geral.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Menu_Principal.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Off_Canvas.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Header.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Footer.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Barra_Carregamento.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Sub_Menu.css">
        <link rel="icon" href="../../imagens/Imagens_PNG/Icon_logo.png">
        <!-- /Estilos Gerais -->


        <!-- Estilos da Página -->
        <link rel="stylesheet" href="../../css/Suporte/Fale_Conosco.css">
        <!-- /Estilos da Página -->


        <!-- /Todos os Estilos -->
        
        
        <?php

            // Conectar ao Banco de Dados 
            $conecta = mysql_connect("mysql.hostinger.com","u447384975_luke","Dragonborne#78") or die ("Não foi possível conectar com o banco de dados");
            mysql_select_db("u447384975_lds",$conecta)or die ("Não foi possível selecionar o banco de dados");

            // Resolver problemas com acentuação 
            mysql_query("SET NAMES 'utf8'");
            mysql_query('SET character_set_connection=utf8');
            mysql_query('SET character_set_client=utf8');
            mysql_query('SET character_set_results=utf8');
        ?>

    </head>
    <body>    
        
    <!-- Menu Off Canvas -->	

    <div class="off-canvas-wrapper">
        <div class="off-canvas position-left" data-transition="overlap" id="Open_Canvas" data-off-canvas> 
            
            <div class="Menu_Vertical">
                <ul class="Menu_Vertical_Links">
                    <label>Aplicações Web</label>

                    <li class="item">
                        <a href="../Web_Applications/WebSites.php">WebSites</a>
                    </li>

                    <li class="item">
                        <a>Aplicativos</a>
                    </li>

                    <li class="item">
                        <a href="../Web_Applications/Suporte.php">Suporte</a>
                    </li>

                    <li class="item">
                        <a href="../Web_Applications/Wireframes.php">Wireframes</a>
                    </li>
                    
                    <label>Portfólios</label>

                    <li class="item">
                        <a href="../Portfolios/All_Applications.php">Todas Aplicações</a>
                    </li>

                    <li class="item">
                        <a>Aplicações Institucionais</a>
                    </li>

                    <li class="item">
                        <a href="../Portfolios/E-Commerce_Applications.php">Aplicações E-Commerce</a>
                    </li>
                    
                    <label>Suporte</label>

                    <li class="item">
                        <a href="../Suporte/Duvidas.php">Dúvidas</a>
                    </li>

                    <li class="item">
                        <a href="../Suporte/Termos_e_Politica.php">Termos e Política</a>
                    </li>

                    <li class="item">
                        <a href="../Suporte/Fale_Conosco.php">Fale Conosco</a>
                    </li>
                    
                    <label>Institucional</label>

                    <li class="item">
                        <a href="../Institucional/Quem_Somos.php">Quem Somos</a>
                    </li>

                    <li class="item">
                        <a href="../Institucional/Linha_do_Tempo.php">Linha do Tempo</a>
                    </li>

                    <li class="item">
                        <a href="../Institucional/Nossos_Servicos.php">Nossos Serviços</a>
                    </li> 
                    
                    <label>Serviços de Designer</label>

                    <li class="item">
                        <a href="../Design/Logotipos.php">Mascotes e Logotipos</a>
                    </li>

                </ul>
                
                <a href="../../index.php" class="Menu_Vertical_Button">Página Inicial</a>
            </div>
        </div>

        <!-- /Menu Off-canvas -->	


		<!-- Conteúdo da Página -->

        <div class="off-canvas-content" data-off-canvas-content>

            <!-- Menu Principal	-->

            <div class="Menu_Principal">   
                <div class="Menu_Principal_Ajuste">

                    <div class="logo_menu"> 
                        <a href="../../index.php">L . D . S</a>
                    </div>

                    <div class="base_options_menu">
                        <ul class="options_menu">
                            <li><a href="../Web_Applications/WebSites.php">Aplicações Web</a></li>
                            <li><a href="../Portfolios/All_Applications.php">Portfólios</a></li>
                            <li><a href="../Suporte/Duvidas.php">Suporte</a></li>
                            <li><a href="../Institucional/Quem_Somos.php">Institucional</a></li>
                            <li><a href="../Design/Logotipos.php">Serviços de Designer</a></li>
                        </ul>				
                    </div>

                    <div class="button_base">
                        <a href="../Suporte/Fale_Conosco.php" class="button_menu">Entre em Contato</a>
                    </div>

                </div>
            </div>    

            <!-- /Menu Principal -->

		
		    <!-- Header -->

            <div class="base_1024px">
                <div class="header_inf">			
                    <h1>Supo<span style="letter-spacing: 3px;">r</span>te</h1>
                    <p>Para que não exista nenhuma dúvida sobre nós ou nossos serviços, desenvolvemos na guia suporte três importantes páginas: dúvidas, termos e política e claro fale conosco.</p>
                </div>    
            </div>

            <div id="particles-js"></div>

            <div class="header_curva"></div>

            <!-- /Header -->


            <!-- Sub Menu -->	

            <div class="base_1024px">
                <ul class="Sub_Menu">
                    <li><a class="neutro" href="Duvidas.php">Dúvidas</a></li>
                    <li><a class="neutro" href="Termos_e_Politica.php">Termos e Política</a></li>
                    <li><a class="ativo" href="Fale_Conosco.php">Fale Conosco</a></li>
                </ul>					
            </div>

            <!-- /Sub Menu -->	    

            <!-- Formulário -->

            <div class="base_1024px">
                <div class="Base_Formulario">
                    <h1>Vamos trabalhar juntos</h1>
                    <p>Entre em contato com Luke para começar algum novo projeto. <br> Nos trabalharemos ao seu lado para fazer grandes coisas.</p>

                    <form class="Formulario" action="Code_Form_Contato.php" method="post">
                        <div class="inteiro">
                            <label>Seu Nome</label>
                            <input type="text" name="nome" required placeholder="Ex: Lucas Campos">
                        </div>

                        <div class="quebrado">
                            <div class="quebrado_item_1">
                                <label>Nome da Empresa</label>
                                <input type="text" name="nome_empresa" required placeholder="Ex: Luke Designer Studios">
                            </div>

                            <div class="quebrado_item_2">
                                <label>Endereço de Email</label>
                                <input type="email" name="email" required placeholder="Ex: lukedesigner@hotmail.com">
                            </div>
                        </div>

                        <div class="quebrado">
                            <div class="quebrado_item_1">
                                <label>Cidade</label>
                                <input type="text" name="cidade" required placeholder="Ex: Praia Grande">
                            </div>

                            <div class="quebrado_item_2">
                                <label>Estado</label>
                                <select name="estado" required>
                                    <option value=""></option>
                                    <option value="AC">Acre</option>
                                    <option value="AL">Alagoas</option>
                                    <option value="AP">Amapá</option>
                                    <option value="AM">Amazonas</option>
                                    <option value="BA">Bahia</option>
                                    <option value="CE">Ceará</option>
                                    <option value="DF">Distrito Federal</option>
                                    <option value="ES">Espírito Santo</option>
                                    <option value="GO">Goiás</option>
                                    <option value="MA">Maranhão</option>
                                    <option value="MT">Mato Grosso</option>
                                    <option value="MS">Mato Grosso do Sul</option>
                                    <option value="MG">Minas Gerais</option>
                                    <option value="PA">Pará</option>
                                    <option value="PB">Paraíba</option>
                                    <option value="PR">Paraná</option>
                                    <option value="PE">Pernambuco</option>
                                    <option value="PI">Piauí</option>
                                    <option value="RJ">Rio de Janeiro</option>
                                    <option value="RN">Rio Grande do Norte</option>
                                    <option value="RS">Rio Grande do Sul</option>
                                    <option value="RO">Rondônia</option>
                                    <option value="RR">Roraima</option>
                                    <option value="SC">Santa Catarina</option>
                                    <option value="SP">São Paulo</option>
                                    <option value="SE">Sergipe</option>
                                    <option value="TO">Tocantins</option>
                                </select>
                            </div>
                        </div>

                        <div class="inteiro">
                            <label>Motivo de contato </label>
                            <select name="motivo" required>
                                <option value=""></option>
                                <option value="Aplicações Web">Aplicações Web</option>
                                <option value="Suporte de Aplicações">Suporte de Aplicações</option>
                                <option value="Serviçoes de Designer">Serviçoes de Designer</option>
                                <option value="Fazer uma Pergunta">Fazer uma Pergunta</option>
                                <option value="Fazer uma Sugestão">Fazer uma Sugestão</option>
                                <option value="Fazer uma Reclamação">Fazer uma Reclamação</option>
                                <option value="Repotar Erros">Reportar Erros</option>
                             </select>
                        </div>

                        <div class="inteiro">
                            <label>Como nós podemos lhe ajudar hoje?</label>
                            <textarea name="mensagem" rows="3" cols="50" required placeholder="Nós conte de forma detalhada o que quer nós dizer"></textarea>
                        </div>

                        <div class="inteiro">
                            <button type="submit" class="button_formulario">Enviar Mensagem</button>
                            <p>Se você preferir entre em contato pelo nosso email lukedesigner@hotmail.com ou tel (13) 9 - 9624 9849</p>
                        </div>
                    </form>
                </div>

            </div>

            <!-- /Formulário -->
            
        
            <!-- Footer -->		

            <div class="footer">
                <div class="footer_section_1">
                    <div class="base_1200px ajustar_float">
                        <div class="footer_chamada_base">
                            <h5>Peça sua aplicação web hoje mesmo!</h5>
                            <p>Venha já conferir as aplicações web que temos a oferecer.</p>
                        </div>

                        <div class="footer_button_base">
                            <a class="footer_button" href="../Web_Applications/WebSites.php">Conferir Aplicações</a>
                        </div>
                    </div>
                </div>

                <div class="footer_section_2">
                    <div class="base_1200px_footer ajustar_float">
                        <div class="footer_inf_base">
                            <div class="footer_lista_ajuste">
                                <div class="inf_item">
                                    <div class="Departamentos">
                                        <h4>Departamentos</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Web_Applications/WebSites.php">Aplicações Web</a></li>
                                            <li><a href="../Design/Logotipos.php">Serviços de Designer</a></li>
                                            <li><a href="../Suporte/Duvidas.php">Nosso Suporte</a></li>
                                            <li><a href="../Institucional/Quem_Somos.php">Institucional</a></li>
                                            <li><a href="../Portfolios/E-Commerce_Applications.php">Portfólios</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="inf_item">
                                    <div class="Institucional">
                                        <h4>Institucional</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Institucional/Quem_Somos.php">Quem Somos</a></li>
                                            <li><a href="../Institucional/Linha_do_Tempo.php">Linha do Tempo</a></li>
                                            <li><a href="../Institucional/Trabalhe_Conosco.php">Trabalhe Conosco</a></li>
                                            <li><a href="../Institucional/Nossos_Servicos.php">Nossos Serviços</a></li>
                                            <li><a href="../Institucional/Membros/Luke.php">Nosso Lider</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="inf_item">
                                    <div class="Suporte">
                                        <h4>Ajuda e Suporte</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Suporte/Duvidas.php">Dúvidas</a></li>
                                            <li><a href="../Suporte/Termos_e_Politica.php#Pagamento">Pagamento</a></li>
                                            <li><a href="../../index.php">Página Inicial</a></li>
                                            <li><a href="../Suporte/Termos_e_Politica.php">Termos e Política</a></li>
                                            <li><a href="../Suporte/Fale_Conosco.php">Fale Conosco</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="inf_item_contato">
                                <div class="Contato">
                                    <h4>Fale Conosco</h4>

                                    <p>Facebook: <a href="https://www.facebook.com/LukeDesignerStudios/">@LukeDesignerStudios</a></p>
                                    <p class="Twitter_P">Twitter: <a href="https://twitter.com/studios_luke">TheLukeDesigner</a></p>

                                    <?php 
                                    $consulta = mysql_query("SELECT * FROM tb_contato");
                                    while ($dados = mysql_fetch_array($consulta)){ ?>

                                    <p>Email:
                                        <?php echo $dados['email']; ?> </p>
                                    <p>Telefone:
                                        <?php echo $dados['telefone']; ?>
                                    </p>

                                    <?php }?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="footer_nav">
                    <div class="base_1200px ajustar_float">
                        <div class="footer_nav_ajuste">
                            <div class="ajustar_float">
                                <div class="footer_logo">
                                    <a href="../../index.php" class="LDS_LOGO">L . D . S</a>
                                </div>

                                <div class="links_footer_base">
                                    <ul class="links_footer">
                                        <li><a href="../../index.php">Página Inicial</a></li>
                                        <li><a href="../Suporte/Termos_e_Politica.php">Termos e Política</a></li>
                                        <li><a data-open="Open_Canvas" aria-expanded="false" aria-controls="Open_Canvas">Mapa do site</a></li>
                                    </ul>     
                                </div>
                            </div>

                            <p class="copyright">© 2018 ‐ Luke Designer Studios.</p>
                        </div>

                        <div class="home_social_base">
                            <ul class="home-social">
                                <li><a href="https://www.facebook.com/LukeDesignerStudios/" class="facebook"></a></li>
                                <li><a href="https://twitter.com/studios_luke" class="twitter"></a></li>
                                <li><a href="../Suporte/Fale_Conosco.php" class="contato"></a></li>
                                <li><a href="https://www.linkedin.com/company/luke-designer-studios/" class="linkedin"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- /Footer -->

            
        </div> <!-- *off-canvas-content -->   
     </div> <!-- /off-canvas-wrapper -->	 	  

        
    <!-- /Conteúdo da Página -->


    <!-- Scripts -->  
      
    <!-- Base do Foundation -->
    <script src="../../js/Foundation/vendor/jquery.js"></script>
    <script src="../../js/Foundation/vendor/what-input.js"></script>
    <script src="../../js/Foundation/vendor/foundation.js"></script>
    <script src="../../js/Foundation/app.js"></script>
  
	<script>
      $(document).foundation();
    </script>  
    <!-- /Base do Foundation -->  
	
         
    <!-- Barra de Carregamento -->  
    <script src="../../js/Barra_de_Carregamento/pace.min.js"></script>
    <!-- /Barra de Carregamento -->    

  
    <!-- Efeito de Particulas -->    
	<script src="../../js/Particles/particles.js"></script>			
	<script src="../../js/Particles/app.js"></script>
    <!-- /Efeito de Particulas -->      
      
    <!-- /Scripts -->  
      
  </body>
</html>