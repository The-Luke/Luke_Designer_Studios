<!doctype html>
<html class="no-js" lang="pt-br">
     <head>
        
        <meta charset="utf-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="Venha conhecer todos os nossos serviços sem grandes dificuldades, com uma pequena descrição especial para cada serviço preparada pela nossa equipe de desevolvimento.">

        <title>Nossos Serviços - Luke Designer Studios</title>

        <!-- Todos os Estilos -->


        <!-- Estilos do Foundation -->
        <link rel="stylesheet" href="../../css/Foundation/foundation.css">
        <link rel="stylesheet" href="../../css/Foundation/app.css">
        <!-- /Estilos do Foundation -->


        <!-- Estilos Gerais -->
        <link rel="stylesheet" href="../../css/Estilos_Gerais/font_face.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Estilo_Geral.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Menu_Principal.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Off_Canvas.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Header.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Footer.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Formularios.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Barra_Carregamento.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Sub_Menu.css">
        <link rel="icon" href="../../imagens/Imagens_PNG/Icon_logo.png">
        <!-- /Estilos Gerais -->


        <!-- Estilos da Página -->
        <link rel="stylesheet" href="../../css/Sobre_Nos/Services.css">    
        <!-- /Estilos da Página -->


        <!-- /Todos os Estilos -->
        
        
        <?php

            // Conectar ao Banco de Dados 
            $conecta = mysql_connect("mysql.hostinger.com","u447384975_luke","Dragonborne#78") or die ("Não foi possível conectar com o banco de dados");
            mysql_select_db("u447384975_lds",$conecta)or die ("Não foi possível selecionar o banco de dados");

            // Resolver problemas com acentuação 
            mysql_query("SET NAMES 'utf8'");
            mysql_query('SET character_set_connection=utf8');
            mysql_query('SET character_set_client=utf8');
            mysql_query('SET character_set_results=utf8');
        ?>

    </head>
    <body>    
        
    <!-- Menu Off Canvas -->	

    <div class="off-canvas-wrapper">
        <div class="off-canvas position-left" data-transition="overlap" id="Open_Canvas" data-off-canvas> 
            
            <div class="Menu_Vertical">
                <ul class="Menu_Vertical_Links">
                    <label>Aplicações Web</label>

                    <li class="item">
                        <a href="../Web_Applications/WebSites.php">WebSites</a>
                    </li>

                    <li class="item">
                        <a>Aplicativos</a>
                    </li>

                    <li class="item">
                        <a href="../Web_Applications/Suporte.php">Suporte</a>
                    </li>

                    <li class="item">
                        <a href="../Web_Applications/Wireframes.php">Wireframes</a>
                    </li>
                    
                    <label>Portfólios</label>

                    <li class="item">
                        <a href="../Portfolios/All_Applications.php">Todas Aplicações</a>
                    </li>

                    <li class="item">
                        <a>Aplicações Institucionais</a>
                    </li>

                    <li class="item">
                        <a href="../Portfolios/E-Commerce_Applications.php">Aplicações E-Commerce</a>
                    </li>
                    
                    <label>Suporte</label>

                    <li class="item">
                        <a href="../Suporte/Duvidas.php">Dúvidas</a>
                    </li>

                    <li class="item">
                        <a href="../Suporte/Termos_e_Politica.php">Termos e Política</a>
                    </li>

                    <li class="item">
                        <a href="../Suporte/Fale_Conosco.php">Fale Conosco</a>
                    </li>
                    
                    <label>Institucional</label>

                    <li class="item">
                        <a href="../Institucional/Quem_Somos.php">Quem Somos</a>
                    </li>

                    <li class="item">
                        <a href="../Institucional/Linha_do_Tempo.php">Linha do Tempo</a>
                    </li>

                    <li class="item">
                        <a href="../Institucional/Nossos_Servicos.php">Nossos Serviços</a>
                    </li> 
                    
                    <label>Serviços de Designer</label>

                    <li class="item">
                        <a href="../Design/Logotipos.php">Mascotes e Logotipos</a>
                    </li>

                </ul>
                
                <a href="../../index.php" class="Menu_Vertical_Button">Página Inicial</a>
            </div>
        </div>

        <!-- /Menu Off-canvas -->	
	


		<!-- Conteúdo da Página -->

        <div class="off-canvas-content" data-off-canvas-content>

            <!-- Menu Principal	-->

            <div class="Menu_Principal">   
                <div class="Menu_Principal_Ajuste">

                    <div class="logo_menu"> 
                        <a href="../../index.php">L . D . S</a>
                    </div>

                    <div class="base_options_menu">
                        <ul class="options_menu">
                            <li><a href="../Web_Applications/WebSites.php">Aplicações Web</a></li>
                            <li><a href="../Portfolios/All_Applications.php">Portfólios</a></li>
                            <li><a href="../Suporte/Duvidas.php">Suporte</a></li>
                            <li><a href="../Institucional/Quem_Somos.php">Institucional</a></li>
                            <li><a href="../Design/Logotipos.php">Serviços de Designer</a></li>
                        </ul>				
                    </div>

                    <div class="button_base">
                        <a href="../Suporte/Fale_Conosco.php" class="button_menu">Entre em Contato</a>
                    </div>

                </div>
            </div>    

            <!-- /Menu Principal -->


            <!-- Header	-->

            <div class="base_1024px">
                <div class="header_inf">			
                    <h1>Institucional</h1>
                    <p>Um pequeno resumo de quem nós somos, e no que nós acreditamos, nossas metas e planos para o resplandecente futuro da Luke Designer Studios que ainda está por vir.</p>
                </div>
            </div>

            <div id="particles-js"></div>

            <div class="header_curva"></div>

            <!-- /Header -->



            <!-- Sub Menu -->	

            <div class="base_1024px">
                <ul class="Sub_Menu">
                    <li><a class="neutro" href="Quem_Somos.php">Quem Somos</a></li>
                    <li><a class="neutro" href="Linha_do_Tempo.php">Linha do Tempo</a></li>
                    <li><a class="ativo" href="Nossos_Servicos.php">Nossos Serviços</a></li>
                </ul>					
            </div>

            <!-- /Sub Menu -->	    


            <!-- Lista de Serviços -->

            <div class="base_1024px">
                <ul class="accordion" data-accordion data-allow-all-closed="true" data-multi-expand="true">
                    <li class="accordion-item is-active" data-accordion-item>
                        <a href="../Web_Applications/WebSites.php" class="accordion-title">Aplicações Web</a>
                        <div class="accordion-content" data-tab-content>

                            <div class="ajustar_float">
                                <div class="Services_Text">
                                    <h3>WebSites</h3>
                                    <p>Empresas de sucesso possuem o seu próprio website, reunindo todas as informações sobre seu negócio em apenas um lugar, como uma verdadeira sede online.</p>
                                    <a href="../Web_Applications/WebSites.php" class="button_preto">Solicitar Website</a>
                                </div>

                                <div class="Services_IMG">
                                    <img src="../../imagens/Imagens_SVG/Geral/online_shop.svg">
                                </div>
                            </div>

                            <br>
                            <br>

                            <div class="ajustar_float">
                                <div class="Services_Text">
                                    <h3>Aplicativos</h3>
                                    <p>O tempo passa e o mercado está sempre mudando, e cabe a sua empresa acompanhar todas as mudanças, tenha seu aplicativo e não fique para trás.</p>
                                    <a href="../Web_Applications/Aplicativos.php" class="button_preto">Solicitar Aplicativo</a>
                                </div>

                                <div class="Services_IMG">
                                    <img src="../../imagens/Imagens_SVG/WebSites/App.svg">
                                </div>
                            </div>

                        </div>
                    </li>

                    <li class="accordion-item" data-accordion-item>
                        <a href="../Web_Applications/WebSites.php" class="accordion-title">Suporte de Aplicações</a>
                        <div class="accordion-content" data-tab-content>

                            <div class="ajustar_float">
                                <div class="Services_Text">
                                    <p>Para um negócio dar certo é preciso investir, e as com aplicações web não é diferente, algumas manutenções para mantê-las atualizadas serão necessárias.</p>
                                    <a href="../Web_Applications/Suporte.php" class="button_preto">Solicitar Website</a>
                                </div>

                                <div class="Services_IMG">
                                    <img src="../../imagens/Imagens_SVG/WebSites/maintenance.svg">
                                </div>
                            </div>

                        </div>
                    </li>

                    <li class="accordion-item" data-accordion-item>
                        <a href="../Web_Applications/WebSites.php" class="accordion-title">Serviços de Designer</a>
                        <div class="accordion-content" data-tab-content>

                            <div class="ajustar_float">
                                <div class="Services_Text">
                                    <p>Negócios de qualidade devem ter de um logo e claro um mascote para representar sua marca, e os nossos designers podem cuidar desta missão.

                                    </p>
                                    <a href="../Design/Logotipos.php" class="button_preto">Solicitar Design</a>
                                </div>

                                <div class="Services_IMG">
                                    <img src="../../imagens/Imagens_SVG/WebSites/Lapis_e_Regua.svg">
                                </div>
                            </div>

                        </div>
                    </li>

                </ul>
            </div>

            <!-- /Lista de Serviços -->
 
        
            <!-- Footer -->		

            <div class="footer">
                <div class="footer_section_1">
                    <div class="base_1200px ajustar_float">
                        <div class="footer_chamada_base">
                            <h5>Peça sua aplicação web hoje mesmo!</h5>
                            <p>Venha já conferir as aplicações web que temos a oferecer.</p>
                        </div>

                        <div class="footer_button_base">
                            <a class="footer_button" href="../Web_Applications/WebSites.php">Conferir Aplicações</a>
                        </div>
                    </div>
                </div>

                <div class="footer_section_2">
                    <div class="base_1200px_footer ajustar_float">
                        <div class="footer_inf_base">
                            <div class="footer_lista_ajuste">
                                <div class="inf_item">
                                    <div class="Departamentos">
                                        <h4>Departamentos</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Web_Applications/WebSites.php">Aplicações Web</a></li>
                                            <li><a href="../Design/Logotipos.php">Serviços de Designer</a></li>
                                            <li><a href="../Suporte/Duvidas.php">Nosso Suporte</a></li>
                                            <li><a href="../Institucional/Quem_Somos.php">Institucional</a></li>
                                            <li><a href="../Portfolios/E-Commerce_Applications.php">Portfólios</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="inf_item">
                                    <div class="Institucional">
                                        <h4>Institucional</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Institucional/Quem_Somos.php">Quem Somos</a></li>
                                            <li><a href="../Institucional/Linha_do_Tempo.php">Linha do Tempo</a></li>
                                            <li><a href="../Institucional/Trabalhe_Conosco.php">Trabalhe Conosco</a></li>
                                            <li><a href="../Institucional/Nossos_Servicos.php">Nossos Serviços</a></li>
                                            <li><a href="../Institucional/Membros/Luke.php">Nosso Lider</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="inf_item">
                                    <div class="Suporte">
                                        <h4>Ajuda e Suporte</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Suporte/Duvidas.php">Dúvidas</a></li>
                                            <li><a href="../Suporte/Termos_e_Politica.php#Pagamento">Pagamento</a></li>
                                            <li><a href="../../index.php">Página Inicial</a></li>
                                            <li><a href="../Suporte/Termos_e_Politica.php">Termos e Política</a></li>
                                            <li><a href="../Suporte/Fale_Conosco.php">Fale Conosco</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="inf_item_contato">
                                <div class="Contato">
                                    <h4>Fale Conosco</h4>

                                    <p>Facebook: <a href="https://www.facebook.com/LukeDesignerStudios/">@LukeDesignerStudios</a></p>
                                    <p class="Twitter_P">Twitter: <a href="https://twitter.com/studios_luke">TheLukeDesigner</a></p>

                                    <?php 
                                    $consulta = mysql_query("SELECT * FROM tb_contato");
                                    while ($dados = mysql_fetch_array($consulta)){ ?>

                                    <p>Email:
                                        <?php echo $dados['email']; ?> </p>
                                    <p>Telefone:
                                        <?php echo $dados['telefone']; ?>
                                    </p>

                                    <?php }?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="footer_nav">
                    <div class="base_1200px ajustar_float">
                        <div class="footer_nav_ajuste">
                            <div class="ajustar_float">
                                <div class="footer_logo">
                                    <a href="../../index.php" class="LDS_LOGO">L . D . S</a>
                                </div>

                                <div class="links_footer_base">
                                    <ul class="links_footer">
                                        <li><a href="../../index.php">Página Inicial</a></li>
                                        <li><a href="../Suporte/Termos_e_Politica.php">Termos e Política</a></li>
                                        <li><a data-open="Open_Canvas" aria-expanded="false" aria-controls="Open_Canvas">Mapa do site</a></li>
                                    </ul>     
                                </div>
                            </div>

                            <p class="copyright">© 2018 ‐ Luke Designer Studios.</p>
                        </div>

                        <div class="home_social_base">
                            <ul class="home-social">
                                <li><a href="https://www.facebook.com/LukeDesignerStudios/" class="facebook"></a></li>
                                <li><a href="https://twitter.com/studios_luke" class="twitter"></a></li>
                                <li><a href="../Suporte/Fale_Conosco.php" class="contato"></a></li>
                                <li><a href="https://www.linkedin.com/company/luke-designer-studios/" class="linkedin"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- /Footer -->


		</div> <!-- off canvas -->                                         
	</div> <!-- off canvas --> 
	  

    <!-- Scripts -->  
      
    <!-- Base do Foundation -->
    <script src="../../js/Foundation/vendor/jquery.js"></script>
    <script src="../../js/Foundation/vendor/what-input.js"></script>
    <script src="../../js/Foundation/vendor/foundation.js"></script>
    <script src="../../js/Foundation/app.js"></script>
  
	<script>
      $(document).foundation();
    </script>  
    <!-- /Base do Foundation -->  
	
         
    <!-- Barra de Carregamento -->  
    <script src="../../js/Barra_de_Carregamento/pace.min.js"></script>
    <!-- /Barra de Carregamento -->    

      
    <!-- Efeito de Particulas -->    
	<script src="../../js/Particles/particles.js"></script>			
	<script src="../../js/Particles/app.js"></script>
    <!-- /Efeito de Particulas -->      
      
    <!-- /Scripts -->  
      
  </body>
</html>