<?php
header('Content-Type: text/html; charset=UTF-8');

$para = "lukedesigner@hotmail.com";
$assunto = "WebSite - Suporte de Aplicação Web";
$assunto = '=?UTF-8?B?'.base64_encode($assunto).'?=';

$nome = $_POST['nome'];
$telefone = $_POST['telefone'];
$email = $_POST['email'];
$cidade = $_POST['cidade'];
$estado = $_POST['estado'];
$bairro = $_POST['bairro'];
$numero = $_POST['numero'];
$suporte_escolhido = $_POST['suporte_escolhido'];


$corpo = "<fieldset>
            <legend>
                <h3 style='font-family:Arial,Helvetica,sans-serif;font-size: 24px;color:#2A2E31;margin: 0;'>Informações do Cliente</h3>
            </legend>

            <strong> Nome:</strong> $nome <br>
            <strong> Telefone:</strong> $telefone<br>
            <strong> Email:</strong> $email<br>
            <strong> Cidade:</strong> $cidade<br>
            <strong> Estado:</strong> $estado<br>
            <strong> Bairro:</strong> $bairro<br>
            <strong> Número:</strong> $numero<br>
            <strong> Opção de Suporte:</strong> $suporte_escolhido<br>
        </fieldset>";

$header = "MIME-Version: 1.1\n";
$header .= 'Content-type: text/html;' . "\n";
$header .= "From: $email Reply-to: $email\n";

mail($para,$assunto,$corpo,$header);

?>

