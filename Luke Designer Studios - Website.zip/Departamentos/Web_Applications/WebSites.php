<!doctype html>
<html class="no-js" lang="pt-br">
    <head>
        
        <meta charset="utf-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="descripton" content="Se você está pensando em investir no seu negócio um website é uma boa maneira de começar, e nós pensando nesse fato separamos dois tipos de websites para você.">

        <title>WebSites - Luke Designer Studios</title>

        <!-- Todos os Estilos -->


        <!-- Estilos do Foundation -->
        <link rel="stylesheet" href="../../css/Foundation/foundation.css">
        <link rel="stylesheet" href="../../css/Foundation/app.css">
        <!-- /Estilos do Foundation -->


        <!-- Estilos Gerais -->
        <link rel="stylesheet" href="../../css/Estilos_Gerais/font_face.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Estilo_Geral.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Menu_Principal.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Off_Canvas.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Header.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Footer.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Barra_Carregamento.css">
        <link rel="stylesheet" href="../../css/Estilos_Gerais/Sub_Menu.css">
        <link rel="icon" href="../../imagens/Imagens_PNG/Icon_logo.png">
        <!-- /Estilos Gerais -->


        <!-- Estilos da Página -->
        <link rel="stylesheet" href="../../css/Web_Applications/Estilo_WebSite.css">
        <!-- /Estilos da Página -->


        <!-- /Todos os Estilos -->
        
        <?php

            // Conectar ao Banco de Dados 
            $conecta = mysql_connect("mysql.hostinger.com","u447384975_luke","Dragonborne#78") or die ("Não foi possível conectar com o banco de dados");
            mysql_select_db("u447384975_lds",$conecta)or die ("Não foi possível selecionar o banco de dados");

            // Resolver problemas com acentuação 
            mysql_query("SET NAMES 'utf8'");
            mysql_query('SET character_set_connection=utf8');
            mysql_query('SET character_set_client=utf8');
            mysql_query('SET character_set_results=utf8');
        ?>

    </head>
    <body>    
      
    <!-- Menu Off Canvas -->	

    <div class="off-canvas-wrapper">
        <div class="off-canvas position-left" data-transition="overlap" id="Open_Canvas" data-off-canvas> 
            
            <div class="Menu_Vertical">
                <ul class="Menu_Vertical_Links">
                    <label>Aplicações Web</label>

                    <li class="item">
                        <a href="../Web_Applications/WebSites.php">WebSites</a>
                    </li>

                    <li class="item">
                        <a>Aplicativos</a>
                    </li>

                    <li class="item">
                        <a href="../Web_Applications/Suporte.php">Suporte</a>
                    </li>

                    <li class="item">
                        <a href="../Web_Applications/Wireframes.php">Wireframes</a>
                    </li>
                    
                    <label>Portfólios</label>

                    <li class="item">
                        <a href="../Portfolios/All_Applications.php">Todas Aplicações</a>
                    </li>

                    <li class="item">
                        <a>Aplicações Institucionais</a>
                    </li>

                    <li class="item">
                        <a href="../Portfolios/E-Commerce_Applications.php">Aplicações E-Commerce</a>
                    </li>
                    
                    <label>Suporte</label>

                    <li class="item">
                        <a href="../Suporte/Duvidas.php">Dúvidas</a>
                    </li>

                    <li class="item">
                        <a href="../Suporte/Termos_e_Politica.php">Termos e Política</a>
                    </li>

                    <li class="item">
                        <a href="../Suporte/Fale_Conosco.php">Fale Conosco</a>
                    </li>
                    
                    <label>Institucional</label>

                    <li class="item">
                        <a href="../Institucional/Quem_Somos.php">Quem Somos</a>
                    </li>

                    <li class="item">
                        <a href="../Institucional/Linha_do_Tempo.php">Linha do Tempo</a>
                    </li>

                    <li class="item">
                        <a href="../Institucional/Nossos_Servicos.php">Nossos Serviços</a>
                    </li> 
                    
                    <label>Serviços de Designer</label>

                    <li class="item">
                        <a href="../Design/Logotipos.php">Mascotes e Logotipos</a>
                    </li>

                </ul>
                
                <a href="../../index.php" class="Menu_Vertical_Button">Página Inicial</a>
            </div>
        </div>

        <!-- /Menu Off-canvas -->	


		<!-- Conteúdo da Página -->

        <div class="off-canvas-content" data-off-canvas-content>

            <!-- Menu Principal	-->

            <div class="Menu_Principal">   
                <div class="Menu_Principal_Ajuste">

                    <div class="logo_menu"> 
                        <a href="../../index.php">L . D . S</a>
                    </div>

                    <div class="base_options_menu">
                        <ul class="options_menu">
                            <li><a href="../Web_Applications/WebSites.php">Aplicações Web</a></li>
                            <li><a href="../Portfolios/All_Applications.php">Portfólios</a></li>
                            <li><a href="../Suporte/Duvidas.php">Suporte</a></li>
                            <li><a href="../Institucional/Quem_Somos.php">Institucional</a></li>
                            <li><a href="../Design/Logotipos.php">Serviços de Designer</a></li>
                        </ul>				
                    </div>

                    <div class="button_base">
                        <a href="../Suporte/Fale_Conosco.php" class="button_menu">Entre em Contato</a>
                    </div>

                </div>
            </div>    

            <!-- /Menu Principal -->


            <!-- Header	-->

            <div class="base_1024px">
                <div class="header_inf">			
                    <h1>Aplicações Web</h1>
                    <p>Se você está pensando em investir no seu negócio uma aplicação web é uma boa maneira de começar, e nós podemos ajudar você com os nossos serviços.</p>
                </div>    
            </div>

            <div id="particles-js"></div>

            <div class="header_curva"></div>

            <!-- /Header -->


            <!-- Sub Menu -->	

            <div class="base_1024px">
                <ul class="Sub_Menu">
                    <li><a class="ativo" href="WebSites.php">WebSites</a></li>
                    <li><a class="neutro">Aplicativos</a></li>
                    <li><a class="neutro" href="Suporte.php">Suporte</a></li>
                    <li><a class="neutro" href="Wireframes.php">Wireframes</a></li>
                </ul>					
            </div>

            <!-- /Sub Menu -->	    


            <!-- Descrição Inicial -->

            <div class="base_1024px">
                <div class="first-description">
                    <h1>Nossa Especialidade</h1> 
                    <p>Sendo a especialidade da Luke Designer Studios a criação websites, nós temos duas categorias disponíveis uma mais completa que a outra, são elas E-Commerce, e Institucional, cada uma delas é voltada para um público específico. Também oferecemos<a href="Suporte.php"> serviços de suporte </a> para websites.</p>
                </div> 
                <hr class="dashed">
            </div>

            <!-- Descrição Inicial -->  


            <!-- WebSites - Chamada 1 -->   

            <div class="base_1200px">    
                <div class="services">

                    <div class="services_item container_hover container_hover_width_1">
                        <img src="../../imagens/Imagens_SVG/Geral/online_shop.svg">
                        <h3>E-Commerce</h3>
                        <p>Grandes lojas não se limitam com só espaços físicos, todas elas possuem uma forte presença online, expandido a sua marca de um modo extraordinário.</p>
                    </div>

                    <div class="services_item container_hover container_hover_width_1">
                        <img src="../../imagens/Imagens_SVG/Sobre_Nos/Website_Institucional.svg">
                        <h3>Institucional</h3>
                        <p>Empresas de sucesso possuem o seu próprio website, juntando as informações sobre seu negócio, e as disponibilizando como uma verdadeira sede online.</p>
                    </div>
                </div>
                <hr class="dashed">
            </div>

            <!-- WebSites - Chamada 1 -->   


            <!-- Vantagens -->	

            <div class="base_1200px vantagens">
                <h1>Vantagens de um website</h1>
                <h4>Conheça seis vantagens incríveis de ter um website</h4>

                <div class="vantage_item">
                    <img src="../../imagens/Imagens_SVG/WebSites/Lucros.svg">
                    <h3>Aumento dos Lucros</h3>
                    <p>Impulsione o seu negócio atingindo uma quantidade maior de pessoas do que com somente uma simples loja física.</p>
                </div>

                <div class="vantage_item">
                    <img src="../../imagens/Imagens_SVG/WebSites/Loja_Online.svg">
                    <h3>Vendendo Online</h3>
                    <p>Deixe que os seus produtos estejam disponíveis 24h por dia, vendendo online e aumentando a eficiência de sua loja.</p>
                </div>

                <div class="vantage_item">
                    <img src="../../imagens/Imagens_SVG/WebSites/Internet.svg">
                    <h3>Expandação do Negócio</h3>
                    <p>Não fique preso em apenas um lugar, venda os seus produtos para pessoas de todo o Brasil, expandindo sua marca.</p>
                </div>

                <br>

                <div class="vantage_item">
                    <img src="../../imagens/Imagens_SVG/WebSites/Horas.svg">
                    <h3>Divulgação Constante</h3>
                    <p>Divulgue sua marca online e tenha uma presença forte, com informações sobre o seu negócio sempre disponíveis.</p>
                </div>

                <div class="vantage_item">
                    <img src="../../imagens/Imagens_SVG/WebSites/Gostar.svg">
                    <h3>Facíl Interação</h3>
                    <p>Possuindo um website você poderá receber muito melhor o feedback de seu público, para melhorar sua eficiência.</p>
                </div>

                <div class="vantage_item">
                    <img src="../../imagens/Imagens_SVG/WebSites/Email.svg">
                    <h3>Contato Facíl</h3>
                    <p>Seus clientes podem falar com você facilmente, diretamente ou acessando as suas informações em seu website.</p>
                </div>
            </div>

            <!-- /Vantagens -->	

            
            <!-- Tabela de WebSites -->

            <section class="Tabela" id="WebSites">
                <h1>WebSites</h1>

                <div class="Tabela_Ajuste">
                    <div class="Tabela_Individual">
                        <h3>E-Commerce</h3>
                        <h2>R$2499,99</h2>
                        <p>Tempo de produção estimado em aproximadamente 120 dias.</p>
                        <ul>
                            <li>Páginas Ilimitadas</li>
                            <li>Backup Automático</li>
                            <li>Domínio Incluso</li>
                            <li>Painel Administrativo</li>
                            <li>Prioridade Moderada</li>
                            <li>Indexado Pelo Google</li>
                            <li>Logotipo Incluso</li>
                            <li>Resposividade Alta</li>
                            <li>Incluso Wireframe</li>
                        </ul>
                        <a class="tabela_btn" href="Form_WebSites.php">Solicitar Agora</a>
                    </div>

                    <div class="Tabela_Individual">
                        <h3>Institucional</h3>
                        <h2>R$1899,99</h2>
                        <p>Tempo de produção estimado em aproximadamente 180 dias.</p>
                        <ul>
                            <li>Páginas Ilimitadas</li>
                            <li>Backup Automático</li>
                            <li>Domínio Incluso</li>
                            <li>Hospedagem Inclusa</li>
                            <li>Prioridade Máxima</li>
                            <li>Indexado Pelo Google</li>
                            <li>Mascote Incluso</li>
                            <li>Logotipo Incluso</li>
                            <li>Prioridade Máxima</li>
                            <li>Resposividade Alta</li>
                            <li>Incluso Wireframe</li>
                        </ul>
                        <a class="tabela_btn" href="Form_WebSites.php">Solicitar Agora</a>
                    </div>
                </div>

                <div class="Aviso">
                    Solicitando nossos serviços você está concordando<br> com todos os nossos
                    <a class="Termos" href="../Suporte/Termos_e_Politica.php">termos e políticas</a>, atuais.
                </div>
            </section>

            <!-- /Tabela de WebSites -->   


            <!-- /Números -->

            <div class="Numeros">
                <div class="base_1024px">

                    <h1>Criação da aplicação web</h1>
                    <h4>Entenda o processo de criação de uma aplicação web</h4>

                    <div class="Numero_Item">
                        <div class="One">
                            <span class="Numero">1</span>
                            <h3>Análise do Negócio</h3>
                            <p>Para começar a elaborarção de um projeto será necessário coletar algumas informações, para isso nós iremos analisar o seu negócio e entender seu funcionamento.</p>
                        </div>
                        <div class="esconder_1 img_n_1"></div>
                    </div>

                    <div class="Numero_Item">
                        <div class="Two">
                            <span class="Numero">2</span>
                            <h3>Elaborando o Layout</h3>
                            <p>Usando as informações coletadas elaboramos um wireframe do projeto, um esqueleto, que será usado para demonstrar a arquitetura de como o layout será.</p>
                        </div>
                    </div>

                    <div class="Numero_Item">
                        <div class="Three">
                            <span class="Numero">3</span>
                            <h3>Processo de Construção</h3>
                            <p>Após a elaboração do wireframe nossa equipe irá começar o desenvolvevimento, nós somos bem comunicativos, então pode esperar comunicação a cada dois dias.</p>
                        </div>
                    </div>

                    <div class="Numero_Item">
                        <div class="Four">
                            <span class="Numero">4</span>
                            <h3>Fazendo a Hospedagem</h3>
                            <p>Após a aplicação estiver finalizada será feita a hospedagem dela em um servidor web, então estará concluido o projeto.</p>

                            <hr>

                            <p><strong>Atenção a hospedagem  da aplicação web será feita apenas quando a segunda parte do <a href="../Suporte/Termos_e_Politica.php#Pagamento" target="_blank">pagamento</a>  for paga.</strong></p>
                        </div>
                    </div>

                </div>
            </div>

            <!-- /Números -->	
          
             
            <!-- Footer -->		

            <div class="footer">
                <div class="footer_section_1">
                    <div class="base_1200px ajustar_float">
                        <div class="footer_chamada_base">
                            <h5>Peça sua aplicação web hoje mesmo!</h5>
                            <p>Venha já conferir as aplicações web que temos a oferecer.</p>
                        </div>

                        <div class="footer_button_base">
                            <a class="footer_button" href="../Web_Applications/WebSites.php">Conferir Aplicações</a>
                        </div>
                    </div>
                </div>

                <div class="footer_section_2">
                    <div class="base_1200px_footer ajustar_float">
                        <div class="footer_inf_base">
                            <div class="footer_lista_ajuste">
                                <div class="inf_item">
                                    <div class="Departamentos">
                                        <h4>Departamentos</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Web_Applications/WebSites.php">Aplicações Web</a></li>
                                            <li><a href="../Design/Logotipos.php">Serviços de Designer</a></li>
                                            <li><a href="../Suporte/Duvidas.php">Nosso Suporte</a></li>
                                            <li><a href="../Institucional/Quem_Somos.php">Institucional</a></li>
                                            <li><a href="../Portfolios/E-Commerce_Applications.php">Portfólios</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="inf_item">
                                    <div class="Institucional">
                                        <h4>Institucional</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Institucional/Quem_Somos.php">Quem Somos</a></li>
                                            <li><a href="../Institucional/Linha_do_Tempo.php">Linha do Tempo</a></li>
                                            <li><a href="../Institucional/Trabalhe_Conosco.php">Trabalhe Conosco</a></li>
                                            <li><a href="../Institucional/Nossos_Servicos.php">Nossos Serviços</a></li>
                                            <li><a href="../Institucional/Membros/Luke.php">Nosso Lider</a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="inf_item">
                                    <div class="Suporte">
                                        <h4>Ajuda e Suporte</h4>
                                        <ul class="footer_lista">
                                            <li><a href="../Suporte/Duvidas.php">Dúvidas</a></li>
                                            <li><a href="../Suporte/Termos_e_Politica.php#Pagamento">Pagamento</a></li>
                                            <li><a href="../../index.php">Página Inicial</a></li>
                                            <li><a href="../Suporte/Termos_e_Politica.php">Termos e Política</a></li>
                                            <li><a href="../Suporte/Fale_Conosco.php">Fale Conosco</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="inf_item_contato">
                                <div class="Contato">
                                    <h4>Fale Conosco</h4>

                                    <p>Facebook: <a href="https://www.facebook.com/LukeDesignerStudios/">@LukeDesignerStudios</a></p>
                                    <p class="Twitter_P">Twitter: <a href="https://twitter.com/studios_luke">TheLukeDesigner</a></p>

                                    <?php 
                                    $consulta = mysql_query("SELECT * FROM tb_contato");
                                    while ($dados = mysql_fetch_array($consulta)){ ?>

                                    <p>Email:
                                        <?php echo $dados['email']; ?> </p>
                                    <p>Telefone:
                                        <?php echo $dados['telefone']; ?>
                                    </p>

                                    <?php }?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="footer_nav">
                    <div class="base_1200px ajustar_float">
                        <div class="footer_nav_ajuste">
                            <div class="ajustar_float">
                                <div class="footer_logo">
                                    <a href="../../index.php" class="LDS_LOGO">L . D . S</a>
                                </div>

                                <div class="links_footer_base">
                                    <ul class="links_footer">
                                        <li><a href="../../index.php">Página Inicial</a></li>
                                        <li><a href="../Suporte/Termos_e_Politica.php">Termos e Política</a></li>
                                        <li><a data-open="Open_Canvas" aria-expanded="false" aria-controls="Open_Canvas">Mapa do site</a></li>
                                    </ul>     
                                </div>
                            </div>

                            <p class="copyright">© 2018 ‐ Luke Designer Studios.</p>
                        </div>

                        <div class="home_social_base">
                            <ul class="home-social">
                                <li><a href="https://www.facebook.com/LukeDesignerStudios/" class="facebook"></a></li>
                                <li><a href="https://twitter.com/studios_luke" class="twitter"></a></li>
                                <li><a href="../Suporte/Fale_Conosco.php" class="contato"></a></li>
                                <li><a href="https://www.linkedin.com/company/luke-designer-studios/" class="linkedin"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- /Footer -->

            
        </div> <!-- *off-canvas-content -->   
     </div> <!-- /off-canvas-wrapper -->	 	  

        
    <!-- /Conteúdo da Página -->


    <!-- Scripts -->  
      
    <!-- Base do Foundation -->
    <script src="../../js/Foundation/vendor/jquery.js"></script>
    <script src="../../js/Foundation/vendor/what-input.js"></script>
    <script src="../../js/Foundation/vendor/foundation.js"></script>
    <script src="../../js/Foundation/app.js"></script>
  
	<script>
      $(document).foundation();
    </script>  
    <!-- /Base do Foundation -->  
	
         
    <!-- Barra de Carregamento -->  
    <script src="../../js/Barra_de_Carregamento/pace.min.js"></script>
    <!-- /Barra de Carregamento -->    

      
    <!-- Efeito de Particulas -->    
	<script src="../../js/Particles/particles.js"></script>			
	<script src="../../js/Particles/app.js"></script>
    <!-- /Efeito de Particulas -->      
      
    <!-- /Scripts -->  

  </body>
</html>