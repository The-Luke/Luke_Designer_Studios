<!doctype html>
<html class="no-js" lang="pt-br">
    <head>

        <meta charset="utf-8" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="descripton" content="Somos a Luke Designer Studios uma equipe desenvolvedora de aplicações web, ajudamos empresas com soluções digitais oferecendo websites, aplicativos e outros serviços.">

        <title>Luke Designer Studios - Página Inicial</title>

        <!-- Todos os Estilos -->


        <!-- Estilos do Foundation -->
        <link rel="stylesheet" href="css/Foundation/foundation.css">
        <link rel="stylesheet" href="css/Foundation/app.css">
        <!-- /Estilos do Foundation -->


        <!-- Estilos Gerais -->
        <link rel="stylesheet" href="css/Estilos_Gerais/font_face.css">
        <link rel="stylesheet" href="css/Estilos_Gerais/Estilo_Geral.css">
        <link rel="stylesheet" href="css/Estilos_Gerais/Menu_Principal.css">
        <link rel="stylesheet" href="css/Estilos_Gerais/Off_Canvas.css">
        <link rel="stylesheet" href="css/Estilos_Gerais/Footer.css">
        <link rel="stylesheet" href="css/Estilos_Gerais/Formularios.css">
        <link rel="stylesheet" href="css/Estilos_Gerais/Barra_Carregamento.css">
        <link rel="icon" href="imagens/Imagens_PNG/Icon_logo.png">
        <!-- /Estilos Gerais -->


        <!-- Estilos da Página -->
        <link rel="stylesheet" href="css/Index/Header_Principal.css">
        <link rel="stylesheet" href="css/Index/Estilo_Index.css">
        <!-- /Estilos da Página -->


        <!-- /Todos os Estilos -->

        <?php

            // Conectar ao Banco de Dados 
            $conecta = mysql_connect("mysql.hostinger.com","u447384975_luke","Dragonborne#78") or die ("Não foi possível conectar com o banco de dados");
            mysql_select_db("u447384975_lds",$conecta)or die ("Não foi possível selecionar o banco de dados");

            // Resolver problemas com acentuação 
            mysql_query("SET NAMES 'utf8'");
            mysql_query('SET character_set_connection=utf8');
            mysql_query('SET character_set_client=utf8');
            mysql_query('SET character_set_results=utf8');
        ?>
        

    </head>	
    <body>
        
    <!-- Menu Off Canvas -->	

    <div class="off-canvas-wrapper">
        <div class="off-canvas position-left" data-transition="overlap" id="Open_Canvas" data-off-canvas> 
            
            <div class="Menu_Vertical">
                <ul class="Menu_Vertical_Links">
                    <label>Aplicações Web</label>

                    <li class="item">
                        <a href="Departamentos/Web_Applications/WebSites.php">WebSites</a>
                    </li>

                    <li class="item">
                        <a>Aplicativos</a>
                    </li>

                    <li class="item">
                        <a href="Departamentos/Web_Applications/Suporte.php">Suporte</a>
                    </li>

                    <li class="item">
                        <a href="Departamentos/Web_Applications/Wireframes.php">Wireframes</a>
                    </li>
                    
                    <label>Portfólios</label>

                    <li class="item">
                        <a href="Departamentos/Portfolios/All_Applications.php">Todas Aplicações</a>
                    </li>

                    <li class="item">
                        <a href="Departamentos/Portfolios/Institucionais_Applications.php">Aplicações Institucionais</a>
                    </li>

                    <li class="item">
                        <a href="Departamentos/Portfolios/E-Commerce_Applications.php">Aplicações E-Commerce</a>
                    </li>
                    
                    <label>Suporte</label>

                    <li class="item">
                        <a href="Departamentos/Suporte/Duvidas.php">Dúvidas</a>
                    </li>

                    <li class="item">
                        <a href="Departamentos/Suporte/Termos_e_Politica.php">Termos e Política</a>
                    </li>

                    <li class="item">
                        <a href="Departamentos/Suporte/Fale_Conosco.php">Fale Conosco</a>
                    </li>
                    
                    <label>Institucional</label>

                    <li class="item">
                        <a href="Departamentos/Institucional/Quem_Somos.php">Quem Somos</a>
                    </li>

                    <li class="item">
                        <a href="Departamentos/Institucional/Linha_do_Tempo.php">Linha do Tempo</a>
                    </li>

                    <li class="item">
                        <a href="Departamentos/Institucional/Nossos_Servicos.php">Nossos Serviços</a>
                    </li> 
                    
                    <label>Serviços de Designer</label>

                    <li class="item">
                        <a href="Departamentos/Design/Logotipos.php">Mascotes e Logotipos</a>
                    </li>

                </ul>
                
                <a href="index.php" class="Menu_Vertical_Button">Página Inicial</a>
            </div>
        </div>

        <!-- /Menu Off-canvas -->	


		<!-- Conteúdo da Página -->

        <div class="off-canvas-content" data-off-canvas-content>
            
             
        <!-- Menu Principal	-->

        <div class="Menu_Principal">   
            <div class="Menu_Principal_Ajuste">

                <div class="logo_menu"> 
                    <a href="index.php">L . D . S</a>
                </div>

                <div class="base_options_menu">
                    <ul class="options_menu">
                        <li><a href="Departamentos/Web_Applications/WebSites.php">Aplicações Web</a></li>
                        <li><a href="Departamentos/Portfolios/All_Applications.php">Portfólios</a></li>
                        <li><a href="Departamentos/Suporte/Duvidas.php">Suporte</a></li>
                        <li><a href="Departamentos/Institucional/Quem_Somos.php">Institucional</a></li>
                        <li><a href="Departamentos/Design/Logotipos.php">Serviços de Designer</a></li>
                    </ul>				
                </div>

                <div class="button_base">
                    <a href="Departamentos/Suporte/Fale_Conosco.php" class="button_menu">Entre em Contato</a>
                </div>

            </div>
        </div>    

        <!-- /Menu Principal -->
    
            
        <!-- Header	-->

        <div class="base_1024px">			
            <div class="header_inf">			
                <h1>Luke Designer Studios</h1>
                <p>Somos a Luke Designer Studios uma equipe desenvolvedora de aplicações web, ajudamos empresas com soluções digitais oferecendo websites, aplicativos e outros serviços.</p>	
            </div>
        </div>
		
		<div id="particles-js"></div>
				
		<div class="header_curva"></div>
	
		<!-- /Header -->    

            
        <!-- Descrição Inicial -->

        <div class="base_1024px">
            <div class="first-description">
                <h1>Aplicações Web e Mais!</h1> 
                <p>Somos uma equipe especializada em desenvolver aplicações web como softwares de desktop, websites e aplicativos mobile, também oferecemos serviços de designer criando mascotes e logos, porém não é tudo, damos suporte para nossas criações com serviços de gestão e manutenção.</p>
            </div> 
            <hr class="dashed">
        </div>

        <!-- Descrição Inicial -->   
                    
           
        <!-- Serviços -->

        <div class="base_1024px">    
            <div class="services">
                <div class="services_item container_hover container_hover_width_1">
                    <img src="imagens/Imagens_SVG/Geral/online_shop.svg">
                    <h3>WebSites</h3>
                    <p>Empresas de sucesso tem seu próprio website, reunindo todas as informações sobre seu negócio em apenas um lugar, como uma verdadeira sede online.</p>
                    <a href="Departamentos/Web_Applications/WebSites.php" class="button_preto">Solicitar WebSite</a>
                </div>

                <div class="services_item container_hover container_hover_width_1">
                    <img src="imagens/Imagens_SVG/WebSites/App.svg">
                    <h3>Aplicativos Mobile</h3>
                    <p>Os tempos passam e o mercado está sempre mudando, e cabe a sua empresa acompanhar todas as mudanças, tenha seu aplicativo e não fique para trás.</p>
                    <a class="button_preto">Ainda Indisponível</a>
                </div>
            </div>
            <hr class="dashed">
        </div>
            
        <!-- Serviços -->

            
        <!-- Portfólios -->

        <div class="base_1024px">
            <div class="trabalho">
                <h1>Trabalhos já realizados</h1>
                <div class="trabalho_ajuste">
                    <p>Desde as nossas primeiras criações até as últimas, todos os nossos trabalhos sejam aplicativos ou websites estam guardados aqui eternizados em nossa história, confira a qualidade do nosso trabalho e vamos trabalhar juntos.</p>
                    <a href="Departamentos/Portfolios/All_Applications.php" class="button_preto">Conhecer Trabalhos</a>
                </div>
            </div>
        </div>

        <div class="trabalhos_img_base efeitos_das_sombras">
            <a href="Departamentos/Portfolios/All_Applications.php">
                <img src="imagens/Imagens_PNG/Pagina_Index/Capturar_3.PNG">
            </a>
        </div>	

        <!-- /Portfólios -->

            
        <!-- Section_black -->

        <section class="section_black">
            <div class="section_black_textos">
                <h1>Luke Designer Studios</h1>
                <p>Nós somos o que já foi apenas uma pequena ideia, na cabeça de um garoto de dezesseis anos, porém foi desse pequeno pensamento que tudo isso surgiu após muito trabalho de Luke, uma desenvolvedora especializada no desenvolvimento de aplicações web para empresas e lojas, nós não só desenvolvemos, mas as mantemos vivas, atualizadas e claro eternizadas em nossa história.</p>
            </div>

            <div class="section_black_base_img">
                <img src="imagens/Imagens_SVG/Geral/The_Husky.svg">
            </div>
        </section>

        <!-- /Section_black -->
            
            
        <!-- Nosso Método -->	

        <section class="base_1200px">
            <div class="metodo">
                <h1>Método de Trabalho</h1>
                <div class="metodo_ajuste">
                    <p>Nós adotamos um método de trabalho simples, porém eficiênte, analisamos o seu negócio para entender seu funcionamento, elaboramos um wireframe para ajudar sua compreensão do projeto. Somos bem comunicativos e odiamos o silêncio, então espere uma comunicação conosco a cada dois dias para compartilhar o progresso e garantir que estamos no caminho certo.</p>
                    <img src="imagens/Imagens_SVG/Index/Metodo_IMG.svg">
                </div>    
            </div>
        </section>	

        <!-- /Nosso Método -->
            
            
        <!-- Formulário -->	

        <div class="section_black">
            <h1>Vamos fazer negócios</h1>
            <p>Seu negócio precisa de uma aplicação web e pensa que podemos ajudar? <br>Então entre já em contato conosco pelo nosso formulário a baixo.</p>	
            
            <form class="formulario" action="PHP/Code_Form_Index.php" method="post">
                <div class="formulario_padrao form_padrao">
                    <div class="inteiro">
                        <label>Nome e Sobrenome</label>
                        <input type="text" name="nome" required placeholder="Seu nome">
                    </div>          

                    <div class="quebrado">
                        <div class="quebrado_item_1">
                            <label>Email</label>
                            <input type="email" name="email" required placeholder="Seu email">
                        </div>

                        <div class="quebrado_item_2">
                            <label>Nome da Empresa</label>
                            <input type="text" name="nome_empresa" required placeholder="Nome da sua empresa">
                        </div>
                     </div> 

                    <div class="inteiro">
                        <label>Como nós podemos lhe ajudar hoje?</label>
                        <textarea name="mensagem" rows="3" cols="50" required placeholder="Nós conte de forma detalhada o que quer nós dizer"></textarea>                           
                    </div>

                    <div class="inteiro">
                        <button type="submit" class="button_formulario_white">Enviar Mensagem</button>
                       <?php 
                        $consulta = mysql_query("SELECT * FROM tb_contato");
                        while ($dados = mysql_fetch_array($consulta)){ ?>   

                        <p>Se você preferir entre em contato pelo nosso telefone <?php echo $dados['telefone']; ?> ou <?php echo $dados['email']; ?> </p>

                        <?php }?>
                    </div>
                </div>
            </form>

        </div>	

        <!-- /Formulário -->


        <!-- Serviços -->

        <div class="services">
            <h1>Um empurrão a mais</h1>
            <h4>Oferecemos total suporte para seu projeto</h4>
            
            <div class="services_item container_hover container_hover_width_1">
                <img src="imagens/Imagens_SVG/WebSites/Lapis_e_Regua.svg">
                <h3>Serviços de Designer</h3>
                <p>Todo negócio de qualidade deve ter de um logo e claro um mascote, e os nossos designers podem cuidar desta missão. Peça agora o seu logo ou mascote!</p>
                <a href="Departamentos/Design/Logotipos.php" class="button_preto">Solicitar Design</a>
            </div>

            <div class="services_item container_hover container_hover_width_1">
                <img src="imagens/Imagens_SVG/WebSites/maintenance.svg">
                <h3>Serviços de Suporte</h3>
                <p>Se deseja manter a sua aplicação web atualizada o nosso time de suporte está pronto para a ação, não perca tempo e peça um update para sua aplicação.</p>
                <a href="Departamentos/Web_Applications/Suporte.php" class="button_preto">Solicitar Suporte</a>
            </div>
        </div>

        <!-- Serviços -->


        <!-- Footer -->		

        <div class="footer">
            <div class="footer_section_1">
                <div class="base_1200px ajustar_float">
                    <div class="footer_chamada_base">
                        <h5>Peça sua aplicação web hoje mesmo!</h5>
                        <p>Venha já conferir as aplicações web que temos a oferecer.</p>
                    </div>

                    <div class="footer_button_base">
                        <a class="footer_button" href="Departamentos/Web_Applications/WebSites.php">Conferir Aplicações</a>
                    </div>
                </div>
            </div>

            <div class="footer_section_2">
                <div class="base_1200px_footer ajustar_float">
                    <div class="footer_inf_base">
                        <div class="footer_lista_ajuste">
                            <div class="inf_item">
                                <div class="Departamentos">
                                    <h4>Departamentos</h4>
                                    <ul class="footer_lista">
                                        <li><a href="Departamentos/Web_Applications/WebSites.php">Aplicações Web</a></li>
                                        <li><a href="Departamentos/Design/Logotipos.php">Serviços de Designer</a></li>
                                        <li><a href="Departamentos/Suporte/Duvidas.php">Nosso Suporte</a></li>
                                        <li><a href="Departamentos/Institucional/Quem_Somos.php">Institucional</a></li>
                                        <li><a href="Departamentos/Portfolios/E-Commerce_Applications.php">Portfólios</a></li>
                                    </ul>
                                </div>
                            </div>

                            <div class="inf_item">
                                <div class="Institucional">
                                    <h4>Institucional</h4>
                                    <ul class="footer_lista">
                                        <li><a href="Departamentos/Institucional/Quem_Somos.php">Quem Somos</a></li>
                                        <li><a href="Departamentos/Institucional/Linha_do_Tempo.php">Linha do Tempo</a></li>
                                        <li><a href="Departamentos/Institucional/Trabalhe_Conosco.php">Trabalhe Conosco</a></li>
                                        <li><a href="Departamentos/Institucional/Nossos_Servicos.php">Nossos Serviços</a></li>
                                        <li><a href="Departamentos/Institucional/Membros/Luke.php">Nosso Lider</a></li>
                                    </ul>
                                </div>
                            </div>

                            <div class="inf_item">
                                <div class="Suporte">
                                    <h4>Ajuda e Suporte</h4>
                                    <ul class="footer_lista">
                                        <li><a href="Departamentos/Suporte/Duvidas.php">Dúvidas</a></li>
                                        <li><a href="Departamentos/Suporte/Termos_e_Politica.php#Pagamento">Pagamento</a></li>
                                        <li><a href="index.php">Página Inicial</a></li>
                                        <li><a href="Departamentos/Suporte/Termos_e_Politica.php">Termos e Política</a></li>
                                        <li><a href="Departamentos/Suporte/Fale_Conosco.php">Fale Conosco</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="inf_item_contato">
                            <div class="Contato">
                                <h4>Fale Conosco</h4>

                                <p>Facebook: <a href="https://www.facebook.com/LukeDesignerStudios/">@LukeDesignerStudios</a></p>
                                <p class="Twitter_P">Twitter: <a href="https://twitter.com/studios_luke">TheLukeDesigner</a></p>

                                <?php 
                                $consulta = mysql_query("SELECT * FROM tb_contato");
                                while ($dados = mysql_fetch_array($consulta)){ ?>

                                <p>Email:
                                    <?php echo $dados['email']; ?> </p>
                                <p>Telefone:
                                    <?php echo $dados['telefone']; ?>
                                </p>

                                <?php }?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer_nav">
                <div class="base_1200px ajustar_float">
                    <div class="footer_nav_ajuste">
                        <div class="ajustar_float">
                            <div class="footer_logo">
                                <a href="index.php" class="LDS_LOGO">L . D . S</a>
                            </div>

                            <div class="links_footer_base">
                                <ul class="links_footer">
                                    <li><a href="index.php">Página Inicial</a></li>
                                    <li><a href="Suporte/Termos_e_Politica.php">Termos e Política</a></li>
                                    <li><a data-open="Open_Canvas" aria-expanded="false" aria-controls="Open_Canvas">Mapa do site</a></li>
                                </ul>     
                            </div>
                        </div>
        
                        <p class="copyright">© 2018 ‐ Luke Designer Studios.</p>
                    </div>

                    <div class="home_social_base">
                        <ul class="home-social">
                            <li><a href="https://www.facebook.com/LukeDesignerStudios/" class="facebook"></a></li>
                            <li><a href="https://twitter.com/studios_luke" class="twitter"></a></li>
                            <li><a href="Departamentos/Suporte/Fale_Conosco.php" class="contato"></a></li>
                            <li><a href="https://www.linkedin.com/company/luke-designer-studios/" class="linkedin"></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- /Footer -->
            
            
        </div> <!-- *off-canvas-content -->   
     </div> <!-- /off-canvas-wrapper -->	 	  


    <!-- Scripts -->  
      
    <!-- Base do Foundation -->
    <script src="js/Foundation/vendor/jquery.js"></script>
    <script src="js/Foundation/vendor/what-input.js"></script>
    <script src="js/Foundation/vendor/foundation.js"></script>
    <script src="js/Foundation/app.js"></script>
  
	<script>
      $(document).foundation();
    </script>  
    <!-- /Base do Foundation -->  
	
         
    <!-- Barra de Carregamento -->  
    <script src="js/Barra_de_Carregamento/pace.min.js"></script>
    <!-- /Barra de Carregamento -->    

      
    <!-- Efeito de Particulas -->    
	<script src="js/Particles/particles.js"></script>			
	<script src="js/Particles/app.js"></script>
    <!-- /Efeito de Particulas -->      
      
    <!-- /Scripts -->  
      
	</body>
</html>