<?php
$conecta = mysql_connect("localhost","root","") or die ("Não foi possível conectar com o banco de daods");
mysql_select_db("luke_designer_studios",$conecta)or die ("Não foi possível selecionar o banco de dados");

// Resolver problemas com acentuação 
mysql_query("SET NAMES 'utf8'");
mysql_query('SET character_set_connection=utf8');
mysql_query('SET character_set_client=utf8');
mysql_query('SET character_set_results=utf8');

?>
