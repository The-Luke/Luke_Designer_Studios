<?php
header('Content-Type: text/html; charset=UTF-8');

$para = "lukedesigner@hotmail.com";
$assunto = "WebSite - Contato Rápido";
$assunto = '=?UTF-8?B?'.base64_encode($assunto).'?=';

$nome = $_POST['nome'];
$email = $_POST['email'];
$nome_empresa = $_POST['nome_empresa'];
$mensagem = $_POST['mensagem'];


$corpo = "<fieldset>
            <legend>
                <h3 style='font-family:Arial,Helvetica,sans-serif;font-size: 24px;color:#2A2E31;margin: 0;'>Informações do Cliente</h3>
            </legend>

            <strong> Nome:</strong> $nome <br>
            <strong> Email:</strong> $email<br>
            <strong> Nome da Empresa:</strong> $nome_empresa<br>
            <strong> Mensagem:</strong> $mensagem<br>
        </fieldset>";

$header = "MIME-Version: 1.1\n";
$header .= 'Content-type: text/html;' . "\n";
$header .= "From: $email Reply-to: $email\n";

mail($para,$assunto,$corpo,$header);

?>

