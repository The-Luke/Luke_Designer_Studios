<?php
$conecta = mysql_connect("mysql.hostinger.com","u447384975_luke","Dragonborne#78") or die ("Não foi possível conectar com o banco de dados");
mysql_select_db("u447384975_lds",$conecta)or die ("Não foi possível selecionar o banco de dados");

// Resolver problemas com acentuação 
mysql_query("SET NAMES 'utf8'");
mysql_query('SET character_set_connection=utf8');
mysql_query('SET character_set_client=utf8');
mysql_query('SET character_set_results=utf8');

?>
